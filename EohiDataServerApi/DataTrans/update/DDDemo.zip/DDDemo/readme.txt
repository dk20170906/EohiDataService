说明：enterprise中是企业的开发，主要有oauth授权与jsapi授权，服务器端调用，客户端调用；
isv中是isv的对接；
开发环境是visual stdio 2013