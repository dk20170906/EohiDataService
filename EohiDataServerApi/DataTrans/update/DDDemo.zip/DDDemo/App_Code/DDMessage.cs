﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// DDMessage 的摘要说明
/// </summary>
public static class DDMessage
{
    static String access_token = "";
    static DateTime access_tokenExpiredDate = DateTime.Now;
   public static void Checkaccess_token()
    {
        if(string.IsNullOrEmpty(access_token))
        {
            var tokenModel = EnterpriseBusiness.GetToken(Config.ECorpId, Config.ECorpSecret);
            access_token = tokenModel.access_token;
            access_tokenExpiredDate = DateTime.Now.AddHours(1.5);
        }else
        {
            if(DateTime.Now> access_tokenExpiredDate)
            {
                var tokenModel = EnterpriseBusiness.GetToken(Config.ECorpId, Config.ECorpSecret);
                access_token = tokenModel.access_token;
                access_tokenExpiredDate = DateTime.Now.AddHours(1.5);
            }
        }
    }


    /// <summary>
    /// 发送企业消息
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="agentid"></param>
    /// <param name="json"></param>
    public static void SendMessage(string userid,string agentid,string json)
    {
        Checkaccess_token();
        string url = "https://oapi.dingtalk.com/message/send?access_token=" + access_token;
        string param = "";
        param = "{\"touser\":\"" + userid + "\",\"agentid\":\"" + agentid + "\","+ json + "}";
        string callback = HttpHelper.Post(url, param);
    }

    /// <summary>
    /// 发送机器人消息
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="agentid"></param>
    /// <param name="json"></param>
    public static void UserSendMessage(string userid, string agentid, string json, string URL)
    {
        //https://oapi.dingtalk.com/robot/send?access_token=997a0e414a6b07306cbc9b9b7dab60c21f737611057f0fa1306edeafe4d52ed2

        Checkaccess_token();
        string url = "https://oapi.dingtalk.com/robot/send?access_token=997a0e414a6b07306cbc9b9b7dab60c21f737611057f0fa1306edeafe4d52ed2";
        url = URL;
        string param = "";
        param = json;
        string callback = HttpHelper.Post(url, param);
    }

    /// <summary>
    /// 获取部门列表
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="agentid"></param>
    /// <param name="json"></param>
    public static void GETdepartment()
    {
        //https://oapi.dingtalk.com/robot/send?access_token=997a0e414a6b07306cbc9b9b7dab60c21f737611057f0fa1306edeafe4d52ed2

        Checkaccess_token();
        string url = "https://oapi.dingtalk.com/department/list?access_token=" + access_token;
  
        string callback = HttpHelper.Get(url);
    }



    /// <summary>
    /// 获取管理员列表
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="agentid"></param>
    /// <param name="json"></param>
    public static void Get_admin()
    {
        //https://oapi.dingtalk.com/robot/send?access_token=997a0e414a6b07306cbc9b9b7dab60c21f737611057f0fa1306edeafe4d52ed2

        Checkaccess_token();
        string url = "https://oapi.dingtalk.com/user/get_admin?access_token=" + access_token;
   
        string callback = HttpHelper.Get(url);
    }

    public static void ProcessinstanceCreate(string json)
    {
        Checkaccess_token();
        string url = "https://eco.taobao.com/router/rest";
        string param = "";
        param = "{\"method\":\"dingtalk.smartwork.bpms.processinstance.create\",\"session\":\"" + access_token + "\",\"timestamp\":\""+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +"\",\"v\":\"2.0\",\"process_code\":\"PROC-WIYJONZV-UASLLOLNSHGCJ3TKTSGN3-0N8LI34J-V\",\"originator_user_id\":\"manager8685\",\"dept_id\":\"39128224\",\"approvers\":[\"manager8685\",\"102325270327306353\"],\"form_component_values\":[{\"name\":\"网吧名称\",\"value\":\"213213213\"}]}";

        string callback = HttpHelper.Post(url, param);
    }


    //public static void ProcessinstanceCreate1(string json)
    //{
    //    IDingTalkClient client = new DefaultDingTalkClient('https://eco.taobao.com/router/rest');
    //    SmartworkBpmsProcessinstanceCreateRequest req = new SmartworkBpmsProcessinstanceCreateRequest();
    //    req.AgentId = 41605932L;
    //    req.ProcessCode = "PROC-EF6YJL35P2-SCKICSB7P750S0YISYKV3-17IBLGZI-1";
    //    req.OriginatorUserId = "manager432";
    //    req.DeptId = 100L;
    //    req.Approvers = "zhangsan,lisi";
    //    req.CcList = "zhangsan,lisi";
    //    req.CcPosition = "START";
    //    List<SmartworkBpmsProcessinstanceCreateRequest.FormComponentValueVoDomain> list2 = new List<SmartworkBpmsProcessinstanceCreateRequest.FormComponentValueVoDomain>();
    //    SmartworkBpmsProcessinstanceCreateRequest.FormComponentValueVoDomain obj3 = new SmartworkBpmsProcessinstanceCreateRequest.FormComponentValueVoDomain();
    //    list2.Add(obj3);
    //    obj3.Name = "请假类型";
    //    obj3.Value = "事假";
    //    obj3.ExtValue = "总天数:1";
    //    req.FormComponentValues_ = list2;
    //    SmartworkBpmsProcessinstanceCreateResponse rsp = client.Execute(req, access_token);
    //    Console.WriteLine(rsp.Body);
    //}
}