﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// MessageEnum 的摘要说明
/// </summary>
public class MessageEnum
{
   public  enum MessageType
    {
        text = 0,
        image = 1,
        voice = 2,
        file = 3,
        link = 4,
        OA=5,
        markdown=6
    }
}